#ifndef QUEUE_H
#define QUEUE_H
#define MAX 10005

#include <iostream>
#include <chrono>
#include <iomanip>
#include <fstream>
#include <vector>
#include "C:\Telkom\AKA\Tubes\json.hpp"

using namespace std;
using namespace std::chrono;
using json = nlohmann::json;


struct Penduduk
{
    string nama;
    string alamat;
    string nik;
};

extern Penduduk queue[MAX];

void resetQueue();
bool isEmpty();
bool isFull();
void enqueue(string nama, string alamat, string nik);
void dequeue();
void displayDummy();
int cariBansosSequential(string nikCari);

#endif