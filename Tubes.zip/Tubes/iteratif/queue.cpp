#include "queue.h"

Penduduk queue[MAX];
int front = -1;
int rear = -1;

void resetQueue() {
    front = -1;
    rear = -1;
}

bool isEmpty() {
    return (front == -1 || front > rear);
}

bool isFull() {
    return (rear == MAX - 1);
}

void enqueue(string nama, string alamat, string nik) {
    if (isFull()) return;
    if (front == -1) front = 0;
    rear++;
    queue[rear].nama = nama;
    queue[rear].alamat = alamat;
    queue[rear].nik = nik;
}

void dequeue() {
    if (isEmpty()) return;
    front++;
}

void displayDummy() {
    if (isEmpty()) {
        cout << "Tidak ada antrian untuk ditampilkan." << endl;
        return;
    } 

    for (int i = front; i <= rear; i++) {
        volatile string tempNama = queue[i].nama;
        volatile string tempAlamat = queue[i].alamat;
        volatile string tempNik = queue[i].nik;
    }

    // cout << "\n--- DAFTAR ANTRIAN BANSOS ---" << endl;
    // for (int i = front; i <= rear; i++) {
    //     cout << i + 1 << ". " << queue[i].nama << " Alamat: " << queue[i].alamat << " (NIK: " << queue[i].nik << ")" << endl;
    // }
}

int cariBansosSequential(string nikCari) {
    if (isEmpty()) {
        return -1;
    }

    for (int i = front; i <= rear; i++) {
        if (queue[i].nik == nikCari) {
            return i;
        }
    }
    return -1;
}