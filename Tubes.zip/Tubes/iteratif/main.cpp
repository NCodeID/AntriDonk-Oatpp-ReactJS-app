#include "queue.h"

int main()
{
    vector<Penduduk> dataBansos;

    ifstream file("initial_data.json");
    if (!file.is_open())
    {
        cout << "Gagal membuka file JSON!" << endl;
        return 1;
    }

    json jData;
    file >> jData;
    file.close();

    for (auto &item : jData)
    {
        Penduduk p;
        p.nama = item.at("nama").get<string>();
        p.nik = item.at("NIK").get<string>();
        p.alamat = item.at("Alamat").get<string>();
        dataBansos.push_back(p);
    }

    int test_sizes[] = {1, 10, 100, 1000, 10000};

    cout << fixed << setprecision(3);
    cout << "====================================================================================" << endl;
    cout << "                 EKSPERIMEN RUNNING TIME SISTEM BANSOS (REKURSIF)                         " << endl;
    cout << "====================================================================================" << endl;
    cout << setw(5) << "N" << setw(12) << "isFull" << setw(12) << "Enqueue" << setw(12) << "Dequeue" << setw(12) << "Display" << setw(15) << "Search" << endl;
    cout << "------------------------------------------------------------------------------------" << endl;

    for (int n : test_sizes)
    {
        resetQueue();

        auto s_full = high_resolution_clock::now();
        for (int i = 0; i < n; i++)
            isFull();
        auto e_full = high_resolution_clock::now();

        auto s_enq = high_resolution_clock::now();
        for (int i = 0; i < n; i++)
        {
            enqueue(dataBansos[i].nama, dataBansos[i].alamat, dataBansos[i].nik);
        }
        auto e_enq = high_resolution_clock::now();

        auto s_disp = high_resolution_clock::now();
        displayDummy();
        auto e_disp = high_resolution_clock::now();

        string targetNIK = dataBansos[n - 1].nik;
        auto s_search = high_resolution_clock::now();
        cariBansosSequential(targetNIK);
        auto e_search = high_resolution_clock::now();

        auto s_deq = high_resolution_clock::now();
        for (int i = 0; i < n; i++)
            dequeue();
        auto e_deq = high_resolution_clock::now();

        double d_full = duration_cast<nanoseconds>(e_full - s_full).count() / 1000.0;
        double d_enq = duration_cast<nanoseconds>(e_enq - s_enq).count() / 1000.0;
        double d_deq = duration_cast<nanoseconds>(e_deq - s_deq).count() / 1000.0;
        double d_disp = duration_cast<nanoseconds>(e_disp - s_disp).count() / 1000.0;
        double d_search = duration_cast<nanoseconds>(e_search - s_search).count() / 1000.0;

        cout << setw(5) << n
             << setw(12) << d_full
             << setw(12) << d_enq
             << setw(12) << d_deq
             << setw(12) << d_disp
             << setw(15) << d_search << endl;
    }

    return 0;
}