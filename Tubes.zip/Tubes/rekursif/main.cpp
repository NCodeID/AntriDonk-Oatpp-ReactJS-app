#include "queue.h"

// int main() {

//     enqueue("budi", "Jl. Merdeka No. 10", "02435043");
//     enqueue("natan", "Jl. Sudirman No. 5", "0237743");
//     enqueue("kafi", "Jl. Diponegoro No. 15", "02323043");
//     enqueue("farisa", "Jl. Gajah Mada No. 20", "02305043");
//     enqueue("yanto", "Jl. Thamrin No. 8", "02326243");
//     enqueue("wkwkwk", "Jl. Thamrin No. 34", "0235043");

//     displayDummy(front);

//     int hasil = cariBansosSequential("02435043", front);

//     if (hasil != -1) {
//     cout << "\nData ditemukan pada antrian ke-" << hasil + 1 << endl;
//     cout << "Nama: " << queue[hasil].nama << endl;
//     cout << "Alamat: " << queue[hasil].alamat << endl;
//     cout << "NIK: " << queue[hasil].nik << endl;
//     } else {
//         cout << "NIK tidak ditemukan dalam antrian." << endl;
//     }

//     // int test_cases[] = {1, 10, 100, 1000, 10000}; // 10000 dikurangi ke 5000 untuk mencegah stack overflow pada rekursi
    
//     // cout << "========================================================================================" << endl;
//     // cout << "              HASIL ANALISIS RUNNING TIME UNTUK SETIAP FUNGSI (REKURSIF)                " << endl;
//     // cout << "========================================================================================" << endl;
//     // cout << setw(7) << "N" << setw(12) << "isFull" << setw(12) << "Enqueue" << setw(12) << "Search" << setw(12) << "Display" << setw(12) << "Dequeue" << endl;
//     // cout << "----------------------------------------------------------------------------------------" << endl;

//     // for (int n : test_cases) {
//     //     resetQueue();

//     //     // 1. Test isFull (N kali)
//     //     auto s1 = high_resolution_clock::now();
//     //     for(int i = 0; i < n; i++) isFull();
//     //     auto e1 = high_resolution_clock::now();

//     //     // 2. Test Enqueue (N kali)
//     //     // Kita masukkan data dummy agar Search bisa bekerja
//     //     auto s2 = high_resolution_clock::now();
//     //     for(int i = 0; i < n; i++) {
//     //         enqueue("Nama", "Alamat", i); // i digunakan sebagai NIK
//     //     }
//     //     auto e2 = high_resolution_clock::now();

//     //     // 3. Test Search Recursive (Worst Case: mencari NIK yang tidak ada)
//     //     auto s3 = high_resolution_clock::now();
//     //     cariBansosSequential(-1, front); 
//     //     auto e3 = high_resolution_clock::now();

//     //     // 4. Test Display Recursive
//     //     auto s4 = high_resolution_clock::now();
//     //     // displayDummy(front); // Dimatikan agar terminal tidak penuh, tapi dihitung waktunya
//     //     auto e4 = high_resolution_clock::now();

//     //     // 5. Test Dequeue (N kali)
//     //     auto s5 = high_resolution_clock::now();
//     //     for(int i = 0; i < n; i++) dequeue();
//     //     auto e5 = high_resolution_clock::now();

//     //     // Hitung durasi dalam microseconds
//     //     double d_full = duration_cast<nanoseconds>(e1 - s1).count() / 1000.0;
//     //     double d_enq  = duration_cast<nanoseconds>(e2 - s2).count() / 1000.0;
//     //     double d_srch = duration_cast<nanoseconds>(e3 - s3).count() / 1000.0;
//     //     double d_disp = duration_cast<nanoseconds>(e4 - s4).count() / 1000.0;
//     //     double d_deq  = duration_cast<nanoseconds>(e5 - s5).count() / 1000.0;

//     //     cout << setw(7) << n 
//     //          << setw(12) << fixed << setprecision(2) << d_full 
//     //          << setw(12) << d_enq 
//     //          << setw(12) << d_srch 
//     //          << setw(12) << d_disp 
//     //          << setw(12) << d_deq << endl;
//     // }

//     // cout << "----------------------------------------------------------------------------------------" << endl;
//     // cout << "*Satuan dalam Microseconds (us)" << endl;

//     // return 0;
// }


int main() {
    vector<Penduduk> dataBansos;
    
    // 1. Membaca file JSON menggunakan nlohmann/json
    ifstream file("initial_data.json");
    if (!file.is_open()) {
        cout << "Gagal membuka file JSON!" << endl;
        return 1;
    }

    json jData;
    file >> jData; // Otomatis parsing seluruh isi file
    file.close();

    // 2. Memasukkan data ke dalam vector struct Penerima
    for (auto& item : jData) {
        Penduduk p;
        p.nama = item.at("nama").get<string>();
        p.nik = item.at("NIK").get<string>();
        p.alamat = item.at("Alamat").get<string>();
        dataBansos.push_back(p);
    }

    // 3. Eksperimen Running Time
    int test_sizes[] = {1, 10, 100, 1000, 10000};

    cout << fixed << setprecision(3);
    cout << "====================================================================================" << endl;
    cout << "                 EKSPERIMEN RUNNING TIME SISTEM BANSOS (REKURSIF)                         " << endl;
    cout << "====================================================================================" << endl;
    cout << setw(5) << "N" << setw(12) << "isFull" << setw(12) << "Enqueue" << setw(12) << "Dequeue" << setw(12) << "Display" << setw(15) << "Search" << endl;
    cout << "------------------------------------------------------------------------------------" << endl;

    for (int n : test_sizes) {
        resetQueue();

        auto s_full = high_resolution_clock::now();
        for(int i = 0; i < n; i++) isFull();
        auto e_full = high_resolution_clock::now();

        auto s_enq = high_resolution_clock::now();
        for(int i = 0; i < n; i++) {
            enqueue(dataBansos[i].nama, dataBansos[i].alamat, dataBansos[i].nik);
        }
        auto e_enq = high_resolution_clock::now();

        auto s_disp = high_resolution_clock::now();
        displayDummy(front);
        auto e_disp = high_resolution_clock::now();

        string targetNIK = dataBansos[n-1].nik;
        auto s_search = high_resolution_clock::now();
        cariBansosSequential(targetNIK, front);
        auto e_search = high_resolution_clock::now();

        auto s_deq = high_resolution_clock::now();
        for(int i = 0; i < n; i++) dequeue();
        auto e_deq = high_resolution_clock::now();

        double d_full = duration_cast<nanoseconds>(e_full - s_full).count() / 1000.0;
        double d_enq = duration_cast<nanoseconds>(e_enq - s_enq).count() / 1000.0;
        double d_deq = duration_cast<nanoseconds>(e_deq - s_deq).count() / 1000.0;
        double d_disp = duration_cast<nanoseconds>(e_disp - s_disp).count() / 1000.0;
        double d_search = duration_cast<nanoseconds>(e_search - s_search).count() / 1000.0;

        cout << setw(5) << n 
             << setw(12) << d_full 
             << setw(12) << d_enq 
             << setw(12) << d_deq 
             << setw(12) << d_disp 
             << setw(15) << d_search << endl;
    }

    return 0;
}