#include "queue.h"

Penduduk queue[MAX];
int front = -1;
int rear = -1;

void resetQueue() {
    front = -1;
    rear = -1;
}

bool isEmpty() {
    return (front == -1 || front > rear);
}

bool isFull() {
    return (rear == MAX - 1);
}

void enqueue(string nama, string alamat, string nik) {
    if (isFull()) return;
    if (front == -1) front = 0;
    rear++;
    queue[rear].nama = nama;
    queue[rear].alamat = alamat;
    queue[rear].nik = nik;
}

void dequeue() {
    if (isEmpty()) return;
    front++;
}

void displayDummy(int index) {

    if (isEmpty() || index > rear) {
        return;
    }

    volatile string tempNama = queue[index].nama;
    volatile string tempNik = queue[index].nik;

    displayDummy(index + 1);

    // cout << index + 1 << ". " << queue[index].nama << " Alamat: " << queue[index].alamat << " (NIK: " << queue[index].nik << ")" << endl;
    // displayDummy(index + 1);
}

int cariBansosSequential(string nikCari, int index) {
    if (isEmpty() || index > rear || index == -1) {
        return -1;
    }

    if (queue[index].nik == nikCari) {
        return index;
    }

    return cariBansosSequential(nikCari, index + 1);
}